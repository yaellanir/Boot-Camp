export function logHello() {
  console.log("hello");
}
export function logGoodbye() {
  console.log("goodbye");
}
