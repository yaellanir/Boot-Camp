import {React, useEffect} from 'react'
import FavoriteColor from './Components/FavoriteColor.jsx'
function App() {
  return (
    <div>
      <FavoriteColor></FavoriteColor>
    </div>
  )
}

export default App