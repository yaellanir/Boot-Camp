import React from "react";

function Counter({ value,color}) {
  return <div style={{color:color}}>{value}</div>;
}

export default Counter;
