import React, {useState, useEffect} from 'react'
import Form from './Components/Form'
import './App.css';


function App() {

// const [toDo, setToDo] = useState("");

  return (
    <div className='App'>To Do List
    <Form action=""/>
    </div>
  )
}
export default App