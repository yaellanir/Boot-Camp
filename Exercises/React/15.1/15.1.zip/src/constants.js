export const urls = {
  PRODUCTS_PAGE: "/products",
  HOMEPAGE_PAGE: "/",
};
