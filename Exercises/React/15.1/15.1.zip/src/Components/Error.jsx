import React from 'react'

function Error() {
  return (
    <div>Error404</div>
  )
}
export default Error
