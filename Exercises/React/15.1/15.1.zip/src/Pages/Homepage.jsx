import React from "react";

function Homepage() {
  return <div></div>;
}

export default Homepage;
