import React from 'react'

function Form() {
  return (
    <div>Form</div>
  )
}

export default Form