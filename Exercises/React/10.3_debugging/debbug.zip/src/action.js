const action = () => {
  document.body.style.background =
    'url("https://i.giphy.com/MPdSxDlGpjvjOAjaSn.gif") no-repeat center fixed';
};
