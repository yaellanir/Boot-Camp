import React from 'react';

export const LargeHeading = (children) => {
  return <h2>{children}</h2>;
};
