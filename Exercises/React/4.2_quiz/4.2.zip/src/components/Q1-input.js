import React from 'react'

const Q1Input = () => {
  return (
    <input type="range" min="1" max="100" defaultValue="50" className="slider" id="myRange"/>

  )
}

export default Q1Input