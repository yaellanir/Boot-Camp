import React from 'react'

const QuizTitle = () => {
  return (
  <h1>how Do You Like Front End?</h1>
  )
}

export default QuizTitle