import React from 'react'

const Q2 = () => {
  return (
<h3>what is your favorite front end feature topic? </h3>
  )
}

export default Q2