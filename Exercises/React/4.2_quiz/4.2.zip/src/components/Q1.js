import React from 'react'

const Q1 = () => {
  return (
    <h3>how much do you love front end </h3>
  )
}

export default Q1