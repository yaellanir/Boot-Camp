import React from 'react'

const Q2Input = () => {
  return (
<input type="text" className="input" />
  )
}

export default Q2Input