import Quiz from "./components/Quiz";
import React from "react";
import "./App.css";

function App() {


  return (
    <div>
      <Quiz/>
    </div>
  );
}

export default App;
