import './box4.css'
import React from "react";

function box4() {
  return (
    <div className="purplebox flex-center"></div>
  );
}

export default box4;