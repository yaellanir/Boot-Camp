import './box3.css'
import React from "react";

function box3({children}) {

  return (
    <div className="pinkbox flex-center">{children}</div>
  );
}

export default box3;