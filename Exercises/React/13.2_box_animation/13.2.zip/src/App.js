import {React, useEffect} from 'react'
import Box from './Components/Box.jsx'
function App() {
  return (
    <div>
      <Box></Box>
    </div>
  )
}

export default App