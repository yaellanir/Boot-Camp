import React from 'react'
import Father from "./Father"


function Grandfather() {
  return (
    <div>
      Grandfather
      <Father/>
    </div>
  )
}

export default Grandfather