import React from 'react'
import Grandson from "./Grandson"
function Son() {
  return (
    <div>Son
      <Grandson/>
    </div>
  )
}

export default Son