import React from "react";

function Counter(props) {
return <h2> {props.text} </h2>;

}

export default Counter;
