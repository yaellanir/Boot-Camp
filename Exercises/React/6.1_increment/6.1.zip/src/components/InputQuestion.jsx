import React from 'react'

const InputQuestion = (props) => {
  return (
    <h3>{props.content}</h3>
  )
}

export default InputQuestion