// todo:  
  //   plan timing !!! 

  // 1. build API
// 2. check crud in postman
// 3. build routes-
//      * home page
//      * shoes page
//      * display shoe (edit + delete)
//      * add shoe
//      * error page
//      * optional additional page (order shoe) 
// 4. build custom components for the app
// 4. check how to cancel a request after it has been sent-?
// 5. after each fetch, save data to state!!! before fetching, check if data exist.
// 6. design + responsive
// 7. use a form constructor  and save input values as an object  (object from entries) for updating or adding shoe 
//? states:
// useReducer in the home page, fetch the data when website is mounted (using useEffect)- array ob shoes objects
// set loading and error components
// in the single shoe-page, set a function to post (update) and delete the shoe.